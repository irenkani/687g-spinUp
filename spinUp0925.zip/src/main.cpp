/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       irenka                                                    */
/*    Created:      Thu Sep 22 2022                                           */
/*    Description:  V5 project  spin up                                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// flywheel             motor         5               
// extension            motor         6               
// leftF                motor         3               
// rightF               motor         4               
// leftB                motor         2               
// rightB               motor         1               
// intake               motor         7               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
//including other files
#include "auton.h"
#include "driverControl.h"    

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  auton();
  wait(3, msec);
  userControl();
}
