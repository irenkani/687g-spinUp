#include "vex.h"

using namespace vex;

//need new auton strat

void auton(void) {
  //empty!
}